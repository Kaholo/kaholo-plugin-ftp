var ftp = require('basic-ftp');
var fs = require('fs');

function upload() {
    let host = "localhost";
    let user = "vinfry";
    let password = "HPjrRWYB9Tz0dZbAjKZ";
    let secure = "true";
    let port = "21";
    let localPath = "D:\\worka\\nodejs\\FTP\\test\\file.txt";
    let remotePath = "f.txt";
    var client = new ftp.Client();
    client.ftp.verbose = true;
    return client.access({host: host, user: user, password: password, port: port, secure: secure}).then(function () {
        let stats = fs.statSync(localPath);
        if (stats.isDirectory()) {
            return client.ensureDir(remotePath).then(function () {
                return client.uploadDir(localPath).then(function () {
                    client.close()
                })
        })
        } else {
            return client.upload(fs.createReadStream(localPath), remotePath).then(function () {
                client.close()
            })
        }
    })
}


//upload()


function removeDir() {
    let host = "localhost";
    let user = "vinfry";
    let password = "HPjrRWYB9Tz0dZbAjKZ";
    let secure = "true";
    let port = "21";
    let remotePath = "somefolder";
    var client = new ftp.Client();
    client.ftp.verbose = true;
    return client.access({host: host, user: user, password: password, port: port, secure: secure}).then(function () {
        return client.removeDir(remotePath).then(function () {
            client.close()
        })
    })
}

//removeDir()

function remove() {
    let host = "localhost";
    let user = "vinfry";
    let password = "HPjrRWYB9Tz0dZbAjKZ";
    let secure = "true";
    let port = "21";
    let remotePath = "55533/file3.txt";
    var client = new ftp.Client();
    client.ftp.verbose = true;
    return client.access({host: host, user: user, password: password, port: port, secure: secure}).then(function () {
        return client.remove(remotePath).then(function () {
                client.close()
        })
    })
}


//remove()

function download() {
    let host = "localhost";
    let user = "vinfry";
    let password = "HPjrRWYB9Tz0dZbAjKZ";
    let secure = "true";
    let port = "21";
    let remotePath = "tttt.zip";
    let localPath = 'D:\\worka\\nodejs\\zip-plugin\\for_zip\\newfolder\\123.zip';
    var client = new ftp.Client();
    client.ftp.verbose = true;
    client.access({host: host, user: user, password: password, port: port, secure: secure}).then(function () {
        return client.download(fs.createWriteStream(localPath), remotePath).then(function () {
            client.close()
        })
    })
}

download()